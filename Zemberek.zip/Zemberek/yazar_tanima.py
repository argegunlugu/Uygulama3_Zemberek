import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from keras.utils import np_utils

#Veri dosya üzerinden okunur.
veriler = pd.read_csv('veriler.csv')

#Girdiler X çıktılar Y değişkenine atanır
X = veriler.iloc[:,:20].values
Y = veriler.iloc[:,20].values

#Çıktı sayısal hale dönüştürülür
from sklearn.preprocessing import LabelEncoder
labelencoder_Y = LabelEncoder()
Y = labelencoder_Y.fit_transform(Y) 
Y = np_utils.to_categorical(Y)    

#Verinin %67'si train, %33'ü test verisi olacak şekilde ayrılır. 
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.33, random_state = 2)

X_train = X_train.astype(float)
X_test = X_test.astype(float)          
#Z-Score normalizasyon işlemi yapılır.
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

import keras
from keras.models import Sequential
from keras.layers import Dense

def build_model():
    classifier = Sequential()
    classifier.add(Dense(units = 512, activation = 'relu', kernel_initializer = 'uniform', input_dim = 20 ))
    classifier.add(Dense(units = 512, activation = 'relu', kernel_initializer = 'uniform'))
    classifier.add(Dense(units = 4, activation = 'softmax', kernel_initializer = 'uniform'))
    classifier.compile(optimizer = 'adam', loss = 'categorical_crossentropy', metrics = ['accuracy'])
    return classifier

classifier = build_model()

#Oluşturulan model train verileri ile eğitilir. Yapay Sinir Ağı eğitilmeye başlar.
#epochs: İterasyon sayısı
classifier.fit(X_train,y_train,epochs=500)

#Test ve train verilerinin doğruluk oranlarına bakılır
lossTest,accuracyTest = classifier.evaluate(X_test,y_test)
lossTrain,accuracyTrain = classifier.evaluate(X_train,y_train)

#0-Ahmet Hamdi Aksekili
#1-Mehmet Akif Ersoy
#2-Musa Kazım
#3-Ahmet Naim

#Sisteme tanıtılmamış bir Mehmet Akif metni girilerek yazar tahmini gözlemlenir.
tahmin = sc.transform(np.array([[41,635,493,6,38,13,5,27,3,2,5,9,133,35,30,29,324,3,0,0]]).astype(float).reshape(1,20))
predict = classifier.predict(tahmin)
predict_class = classifier.predict_classes(tahmin)[0]
print(predict_class)


